<?php   
return [
    'word' => 'أعمالنا'
];