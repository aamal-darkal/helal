<?php   
return [
    'word' => 'My Work'
];